// EventCore Frontend Controller
const API_BASE = '/api/v1';

async function fetchBridgeStatus() {
  try {
    const r = await fetch(`${API_BASE}/bio-bridge/status`);
    const data = await r.json();
    const el = document.getElementById('bridge-status');
    if (!el) return;
    if (data.online) {
      el.innerHTML = `<span class="status-dot status-online"></span>Bio-ERP v5 Online`;
      el.classList.add('badge-success');
    } else {
      el.innerHTML = `<span class="status-dot status-offline"></span>Bio-ERP Offline`;
      el.classList.add('badge-danger');
    }
  } catch (e) {
    console.error('Bridge status check failed', e);
  }
}

function initTooltips() {
  document.querySelectorAll('[data-tooltip]').forEach(el => {
    el.addEventListener('mouseenter', () => { });
  });
}

document.addEventListener('DOMContentLoaded', () => {
  fetchBridgeStatus();
  setInterval(fetchBridgeStatus, 30000);
  initTooltips();
});
