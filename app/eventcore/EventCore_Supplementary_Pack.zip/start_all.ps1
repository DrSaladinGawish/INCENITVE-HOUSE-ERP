# Unified Launcher: Bio-ERP (8000) + EventCore (8001)
$bioPath = "D:\Bio_ERP"
$ecPath  = "D:\EventCore_ERP"

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "     BIO-ERP + EventCore Launcher           " -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan

# Start Bio-ERP v5
Write-Host "`n[1/2] Starting Bio-ERP v5 on port 8000..." -ForegroundColor Green
$bio = Start-Process powershell -ArgumentList "-NoExit","-Command","cd '$bioPath'; uvicorn app.main:app --host 0.0.0.0 --port 8000" -PassThru
Start-Sleep 3

# Start EventCore
Write-Host "[2/2] Starting EventCore ERP on port 8001..." -ForegroundColor Green
$ec = Start-Process powershell -ArgumentList "-NoExit","-Command","cd '$ecPath'; uvicorn backend.app.main:app --host 0.0.0.0 --port 8001" -PassThru
Start-Sleep 2

Write-Host "`nBoth systems running:" -ForegroundColor Cyan
Write-Host "   Bio-ERP    -> http://localhost:8000" -ForegroundColor White
Write-Host "   EventCore  -> http://localhost:8001/dashboard" -ForegroundColor White
Write-Host "`nPress Enter to stop both..."
Read-Host

Stop-Process -Id $bio.Id -Force -ErrorAction SilentlyContinue
Stop-Process -Id $ec.Id -Force -ErrorAction SilentlyContinue
Write-Host "Stopped." -ForegroundColor Yellow
