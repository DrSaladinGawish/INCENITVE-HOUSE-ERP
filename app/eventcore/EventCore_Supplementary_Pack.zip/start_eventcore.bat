@echo off
echo Starting EventCore ERP on port 8001...
cd /d "%~dp0"
if exist venv\Scripts\activate.bat (
    call venv\Scripts\activate.bat
) else (
    echo No venv found, using global Python
)
uvicorn backend.app.main:app --host 0.0.0.0 --port 8001 --reload
echo EventCore stopped.
pause
