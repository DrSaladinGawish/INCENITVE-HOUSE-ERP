"""Seed EventCore with demo data for testing."""
import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from backend.app.database import Base
from backend.app.models.vendor import Vendor
from backend.app.models.client import Client
from backend.app.models.job import Job
from backend.app.models.line_item import LineItem
from backend.app.models.invoice import Invoice

DATABASE_URL = "sqlite:///./backend/eventcore.db"
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine)

def seed():
    db = SessionLocal()
    try:
        vendors = [
            Vendor(name="Al-Futtaim Events", contact_person="Ahmed", email="ahmed@alfuttaim.ae", category="AV Equipment", is_active=True),
            Vendor(name="Royal Catering", contact_person="Fatima", email="fatima@royalcatering.ae", category="Catering", is_active=True),
            Vendor(name="Dubai Stage Lights", contact_person="Omar", email="omar@dsl.ae", category="Lighting", is_active=True),
            Vendor(name="Premium Florals", contact_person="Sarah", email="sarah@premiumflorals.ae", category="Decor", is_active=True),
            Vendor(name="Gulf Security", contact_person="Khalid", email="khalid@gulfsec.ae", category="Security", is_active=True),
        ]
        db.add_all(vendors)
        db.commit()

        clients = [
            Client(name="Emirates Bank", email="events@emiratesbank.ae", company="Emirates Bank PJSC", is_active=True),
            Client(name="Ministry of Education", email="procurement@moe.gov.ae", company="MOE UAE", is_active=True),
            Client(name="Private Wedding - Al Mansouri", email="bride@example.com", is_active=True),
        ]
        db.add_all(clients)
        db.commit()

        job = Job(title="Annual Gala 2026", client_id=1, event_date="2026-06-15", venue="Dubai Opera", status="confirmed")
        db.add(job)
        db.commit()

        lines = [
            LineItem(job_id=job.id, description="Stage Setup & AV", quantity=1, unit_price=45000, category="Production", sub_category="AV Equipment"),
            LineItem(job_id=job.id, description="Catering - 500 guests", quantity=500, unit_price=320, category="Catering", sub_category="Buffet"),
            LineItem(job_id=job.id, description="Floral Centerpieces", quantity=50, unit_price=850, category="Decor", sub_category="Floral"),
            LineItem(job_id=job.id, description="Security Detail", quantity=12, unit_price=1200, category="Security", sub_category="Personnel"),
        ]
        db.add_all(lines)
        db.commit()

        inv = Invoice(job_id=job.id, invoice_number="EC-INV-2026-001", issue_date="2026-05-20", due_date="2026-06-10", status="sent", total_amount=sum(l.quantity*l.unit_price for l in lines))
        db.add(inv)
        db.commit()

        print("Seeded: 5 vendors, 3 clients, 1 job, 4 line items, 1 invoice")
    finally:
        db.close()

if __name__ == "__main__":
    seed()
