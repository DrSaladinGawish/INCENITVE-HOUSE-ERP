"""Sergey Protocol compatible audit trail for EventCore."""
import json
from datetime import datetime
from typing import Any, Optional
from pathlib import Path

AUDIT_LOG = Path("backend/audit_trail.jsonl")

def log_event(
    entity_type: str,
    entity_id: int,
    action: str,
    user: Optional[str] = None,
    before: Optional[dict] = None,
    after: Optional[dict] = None,
    meta: Optional[dict] = None
) -> None:
    entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "system": "EventCore_ERP",
        "entity_type": entity_type,
        "entity_id": entity_id,
        "action": action,
        "user": user or "system",
        "before": before,
        "after": after,
        "meta": meta or {}
    }
    AUDIT_LOG.parent.mkdir(parents=True, exist_ok=True)
    with open(AUDIT_LOG, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False, default=str) + "\n")

def get_trail(entity_type: Optional[str] = None, limit: int = 100) -> list[dict]:
    if not AUDIT_LOG.exists():
        return []
    lines = AUDIT_LOG.read_text(encoding="utf-8").strip().split("\n")
    records = [json.loads(line) for line in lines if line.strip()]
    if entity_type:
        records = [r for r in records if r["entity_type"] == entity_type]
    return records[-limit:]
