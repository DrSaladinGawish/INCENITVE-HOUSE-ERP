"""Background queue + retry logic for Bio-ERP sync."""
import asyncio
from typing import List, Dict, Any
from backend.app.core.eventcore_bridge import bridge
from backend.app.services.audit_service import log_event

_sync_queue: asyncio.Queue = asyncio.Queue()
_is_processing: bool = False

async def enqueue(entity_type: str, payload: List[Dict[str, Any]], user: str = "system") -> None:
    await _sync_queue.put({"entity_type": entity_type, "payload": payload, "user": user})
    if not _is_processing:
        asyncio.create_task(_process_queue())

async def _process_queue() -> None:
    global _is_processing
    _is_processing = True
    try:
        while not _sync_queue.empty():
            task = await _sync_queue.get()
            try:
                if task["entity_type"] == "vendor":
                    result = await bridge.sync_vendors(task["payload"])
                elif task["entity_type"] == "gl_account":
                    result = await bridge.sync_gl_accounts(task["payload"])
                elif task["entity_type"] == "journal_entry":
                    result = await bridge.sync_journal_entries(task["payload"])
                else:
                    result = {"status": "unknown_entity"}
                log_event(task["entity_type"], 0, "bridge_sync", task["user"], after=result)
            except Exception as e:
                log_event(task["entity_type"], 0, "bridge_sync_failed", task["user"], after={"error": str(e)})
    finally:
        _is_processing = False

async def get_bridge_status() -> dict:
    return await bridge.status()
