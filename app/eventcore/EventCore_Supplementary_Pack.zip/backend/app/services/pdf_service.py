"""PDF generation for invoices, vouchers, reports."""
from io import BytesIO
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors
from typing import List, Dict, Any

def generate_invoice_pdf(invoice_data: Dict[str, Any]) -> bytes:
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4)
    styles = getSampleStyleSheet()
    story = []

    story.append(Paragraph(f"<b>INVOICE {invoice_data.get('invoice_number','')}</b>", styles['Title']))
    story.append(Spacer(1, 12))

    items = [["Description", "Qty", "Unit Price", "Amount"]]
    for line in invoice_data.get("line_items", []):
        items.append([
            line.get("description",""),
            str(line.get("quantity",1)),
            f"{line.get('unit_price',0):,.2f}",
            f"{line.get('amount',0):,.2f}"
        ])
    items.append(["","","Total", f"{invoice_data.get('total_amount',0):,.2f}"])

    table = Table(items, colWidths=[250,50,100,100])
    table.setStyle(TableStyle([
        ('BACKGROUND',(0,0),(-1,0),colors.HexColor('#1a1a2e')),
        ('TEXTCOLOR',(0,0),(-1,0),colors.whitesmoke),
        ('ALIGN',(0,0),(-1,-1),'CENTER'),
        ('GRID',(0,0),(-1,-1),0.5,colors.grey),
    ]))
    story.append(table)
    doc.build(story)
    buffer.seek(0)
    return buffer.read()
