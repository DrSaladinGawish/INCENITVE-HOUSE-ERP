"""Stub email service - replace with SMTP in production."""
from backend.app.services.audit_service import log_event

async def send_email(to: str, subject: str, body: str, template: str = "default") -> dict:
    log_event("email", 0, "send", meta={"to": to, "subject": subject, "template": template})
    return {"status": "queued", "to": to, "subject": subject}
