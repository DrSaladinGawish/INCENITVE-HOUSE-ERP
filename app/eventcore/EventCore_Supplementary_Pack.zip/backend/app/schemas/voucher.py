from pydantic import BaseModel, ConfigDict
from datetime import datetime, date
from typing import Optional

class PaymentVoucherBase(BaseModel):
    voucher_number: str
    vendor_id: Optional[int] = None
    amount: float
    date: date
    description: Optional[str] = None
    payment_method: Optional[str] = "cash"
    status: str = "pending"
    approved_by: Optional[str] = None

class PaymentVoucherCreate(PaymentVoucherBase):
    pass

class PaymentVoucherResponse(PaymentVoucherBase):
    model_config = ConfigDict(from_attributes=True)
    id: int
    created_at: datetime

class ReceiptVoucherBase(BaseModel):
    voucher_number: str
    client_id: Optional[int] = None
    amount: float
    date: date
    description: Optional[str] = None
    payment_method: Optional[str] = "cash"
    status: str = "pending"

class ReceiptVoucherCreate(ReceiptVoucherBase):
    pass

class ReceiptVoucherResponse(ReceiptVoucherBase):
    model_config = ConfigDict(from_attributes=True)
    id: int
    created_at: datetime
