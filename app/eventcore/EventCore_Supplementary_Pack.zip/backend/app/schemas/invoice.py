from pydantic import BaseModel, ConfigDict
from datetime import datetime, date
from typing import Optional, List

class InvoiceLineItem(BaseModel):
    description: str
    quantity: float = 1.0
    unit_price: float
    amount: Optional[float] = None

class InvoiceBase(BaseModel):
    job_id: int
    invoice_number: str
    issue_date: date
    due_date: Optional[date] = None
    status: str = "draft"
    line_items: List[InvoiceLineItem] = []

class InvoiceCreate(InvoiceBase):
    pass

class InvoiceResponse(InvoiceBase):
    model_config = ConfigDict(from_attributes=True)
    id: int
    total_amount: Optional[float] = None
    created_at: datetime
