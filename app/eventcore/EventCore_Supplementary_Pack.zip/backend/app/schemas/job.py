from pydantic import BaseModel, ConfigDict
from datetime import datetime, date
from typing import Optional, List

class JobLineItem(BaseModel):
    description: str
    quantity: float = 1.0
    unit_price: float
    category: Optional[str] = None
    sub_category: Optional[str] = None

class JobBase(BaseModel):
    title: str
    client_id: int
    event_date: Optional[date] = None
    venue: Optional[str] = None
    status: str = "draft"
    notes: Optional[str] = None
    line_items: List[JobLineItem] = []

class JobCreate(JobBase):
    pass

class JobResponse(JobBase):
    model_config = ConfigDict(from_attributes=True)
    id: int
    total_amount: Optional[float] = None
    created_at: datetime
    updated_at: Optional[datetime] = None
