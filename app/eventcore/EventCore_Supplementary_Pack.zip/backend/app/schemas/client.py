from pydantic import BaseModel, ConfigDict
from datetime import datetime
from typing import Optional

class ClientBase(BaseModel):
    name: str
    email: Optional[str] = None
    phone: Optional[str] = None
    company: Optional[str] = None
    address: Optional[str] = None
    is_active: bool = True

class ClientCreate(ClientBase):
    pass

class ClientResponse(ClientBase):
    model_config = ConfigDict(from_attributes=True)
    id: int
    created_at: datetime
