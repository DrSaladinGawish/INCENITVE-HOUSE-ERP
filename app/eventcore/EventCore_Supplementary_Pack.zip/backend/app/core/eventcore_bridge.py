"""Bio-ERP <-> EventCore bidirectional bridge client."""
import httpx
from fastapi import HTTPException
from backend.app.core.config import get_settings

settings = get_settings()

class BioERPBridge:
    def __init__(self):
        self.base = settings.BIO_ERP_BASE_URL.rstrip("/")
        self.prefix = settings.BIO_ERP_API_PREFIX.rstrip("/")
        self.token = settings.BIO_ERP_BRIDGE_TOKEN
        self.headers = {"X-Bridge-Token": self.token, "Content-Type": "application/json"}

    async def status(self) -> dict:
        async with httpx.AsyncClient(timeout=5.0) as client:
            try:
                r = await client.get(f"{self.base}{self.prefix}/health", headers=self.headers)
                return {"online": r.status_code == 200, "bio_erp_version": r.json().get("version", "unknown")}
            except Exception as e:
                return {"online": False, "error": str(e)}

    async def sync_vendors(self, vendors: list[dict]) -> dict:
        url = f"{self.base}{self.prefix}/eventcore-bridge/vendors"
        async with httpx.AsyncClient(timeout=30.0) as client:
            r = await client.post(url, json=vendors, headers=self.headers)
            r.raise_for_status()
            return r.json()

    async def sync_gl_accounts(self, accounts: list[dict]) -> dict:
        url = f"{self.base}{self.prefix}/eventcore-bridge/gl-accounts"
        async with httpx.AsyncClient(timeout=30.0) as client:
            r = await client.post(url, json=accounts, headers=self.headers)
            r.raise_for_status()
            return r.json()

    async def sync_journal_entries(self, entries: list[dict]) -> dict:
        url = f"{self.base}{self.prefix}/eventcore-bridge/journal-entries"
        async with httpx.AsyncClient(timeout=30.0) as client:
            r = await client.post(url, json=entries, headers=self.headers)
            r.raise_for_status()
            return r.json()

bridge = BioERPBridge()
