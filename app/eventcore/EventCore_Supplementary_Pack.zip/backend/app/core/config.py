from pydantic_settings import BaseSettings
from functools import lru_cache

class Settings(BaseSettings):
    ENVIRONMENT: str = "development"
    DEBUG: bool = True
    EVENTCORE_PORT: int = 8001
    EVENTCORE_HOST: str = "0.0.0.0"
    DATABASE_URL: str = "sqlite:///./backend/eventcore.db"
    SECRET_KEY: str = "eventcore-dev-secret"

    # Bio-ERP bridge
    BIO_ERP_BASE_URL: str = "http://localhost:8000"
    BIO_ERP_API_PREFIX: str = "/api/v1"
    BIO_ERP_BRIDGE_TOKEN: str = "bio-erp-eventcore-bridge-2026"
    BRIDGE_AUTO_SYNC: bool = True
    BRIDGE_BATCH_SIZE: int = 100
    BRIDGE_RETRY_ATTEMPTS: int = 3

    class Config:
        env_file = ".env"
        extra = "ignore"

@lru_cache()
def get_settings() -> Settings:
    return Settings()
