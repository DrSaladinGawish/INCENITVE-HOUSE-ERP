# EventCore ERP v1.0 - Standalone Event Management System

**Location:** `D:\EventCore_ERP`  
**Port:** 8001  
**Linked to:** Bio-ERP v5 (Port 8000)

## Structure (matches your existing tree)
```
D:\EventCore_ERP\
├── backend\
│   ├── app\
│   │   ├── main.py              <- Entry point
│   │   ├── config.py            <- Settings
│   │   ├── database.py          <- SQLAlchemy engine
│   │   ├── core\               <- Config, security, bridge
│   │   ├── models\             <- 28 ORM models (your existing)
│   │   ├── routers\            <- 25 routers (your existing)
│   │   ├── schemas\            <- Pydantic schemas (this pack)
│   │   ├── services\           <- Business logic (this pack)
│   │   └── scripts\            <- Seeds & migrations
│   └── eventcore.db             <- SQLite (dev)
├── templates\                  <- Jinja2 templates (your existing)
├── static\                    <- CSS, JS, images
├── .env                        <- Environment config
├── requirements.txt            <- Dependencies
├── docker-compose.yml          <- PostgreSQL + app
├── start_eventcore.bat         <- Windows launcher
├── start_all.ps1               <- Unified Bio-ERP + EventCore
└── README.md                   <- This file
```

## Quick Start
```powershell
# 1. Merge this pack into D:\EventCore_ERP (skip existing files)
# 2. Install deps
pip install -r requirements.txt

# 3. Seed demo data (optional)
python -m backend.app.scripts.seed_db

# 4. Launch
.\start_eventcore.bat
# OR launch both ERPs:
.\start_all.ps1
```

## Bio-ERP Bridge
| Direction | Endpoint | Action |
|-----------|----------|--------|
| EventCore -> Bio-ERP | POST /api/v1/eventcore-bridge/vendors | Sync vendors |
| EventCore -> Bio-ERP | POST /api/v1/eventcore-bridge/gl-accounts | Chart of accounts |
| EventCore -> Bio-ERP | POST /api/v1/eventcore-bridge/journal-entries | Financial txns |
| Status | GET /api/v1/bio-bridge/status | Online/Offline check |

## Data Quality Fix
The `data_quality.py` router (add to your routers) includes:
- POST /api/v1/data-quality/repair - Backfills missing monetary values from line items
- GET /api/v1/data-quality/density - Shows current % of rows with monetary values
